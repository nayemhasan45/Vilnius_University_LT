public class Vector {
    private static final int MAX_LENGTH = 15;
    private double[] elements;
    private int length;

    // Constructor
    public Vector(int length) throws VectorException {
        if (length <= 0 || length > MAX_LENGTH)
            throw new VectorException("Invalid length: must be 1–" + MAX_LENGTH);
        this.length = length;
        this.elements = new double[length];
    }

    // Copy array elements
    public void copyElements(double[] arr) throws VectorException {
        if (arr.length != length)
            throw new VectorException("Array length does not match vector length");
        for (int i = 0; i < length; i++)
            elements[i] = arr[i];
    }

    // Set element
    public void setElement(int i, double value) throws VectorException {
        if (i < 0 || i >= length)
            throw new VectorException("Index out of range: " + i);
        elements[i] = value;
    }

    // Get element
    public double getElement(int i) throws VectorException {
        if (i < 0 || i >= length)
            throw new VectorException("Index out of range: " + i);
        return elements[i];
    }

    // Get and set length
    public int get_l() {
        return length;
    }

    public void set_l(int newLength) throws VectorException {
        if (newLength <= 0 || newLength > MAX_LENGTH)
            throw new VectorException("New length exceeds MAX_LENGTH");
        double[] newArr = new double[newLength];
        for (int i = 0; i < Math.min(length, newLength); i++)
            newArr[i] = elements[i];
        elements = newArr;
        length = newLength;
    }

    // Print vector
    public void print() {
        System.out.print("(");
        for (int i = 0; i < length; i++) {
            System.out.print(elements[i]);
            if (i < length - 1)
                System.out.print(", ");
        }
        System.out.println(")");
    }

    // Scalar (dot) product
    public double scalarProduct(Vector v) throws VectorException {
        if (v.length != this.length)
            throw new VectorException("Vectors must have the same length for scalar product");
        double sum = 0;
        for (int i = 0; i < length; i++)
            sum += this.elements[i] * v.elements[i];
        return sum;
    }

    // Vector (cross) product – only for 3D
    public Vector vectorProduct(Vector v) throws VectorException {
        if (this.length != 3 || v.length != 3)
            throw new VectorException("Vector product is defined only for 3D vectors");
        Vector result = new Vector(3);
        result.elements[0] = this.elements[1] * v.elements[2] - this.elements[2] * v.elements[1];
        result.elements[1] = this.elements[2] * v.elements[0] - this.elements[0] * v.elements[2];
        result.elements[2] = this.elements[0] * v.elements[1] - this.elements[1] * v.elements[0];
        return result;
    }
}
