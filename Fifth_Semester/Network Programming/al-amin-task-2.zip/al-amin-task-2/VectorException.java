public class VectorException extends Exception {
    public VectorException(String message) {
        super(message);
    }
}
