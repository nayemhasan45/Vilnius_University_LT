import java.util.Scanner;

public class TestVector {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        try {
            System.out.print("Enter length of the vectors (max 15): ");
            int len = input.nextInt();

            Vector v1 = new Vector(len);
            Vector v2 = new Vector(len);

            System.out.println("\nEnter elements of Vector 1:");
            double[] arr1 = new double[len];
            for (int i = 0; i < len; i++) {
                System.out.print("v1[" + i + "] = ");
                arr1[i] = input.nextDouble();
            }
            v1.copyElements(arr1);

            System.out.println("\nEnter elements of Vector 2:");
            double[] arr2 = new double[len];
            for (int i = 0; i < len; i++) {
                System.out.print("v2[" + i + "] = ");
                arr2[i] = input.nextDouble();
            }
            v2.copyElements(arr2);

            System.out.print("\nVector 1: ");
            v1.print();
            System.out.print("Vector 2: ");
            v2.print();

            // Scalar product
            double scalar = v1.scalarProduct(v2);
            System.out.println("\nScalar product = " + scalar);

            // Vector product (only if 3D)
            if (len == 3) {
                Vector cross = v1.vectorProduct(v2);
                System.out.print("Vector product = ");
                cross.print();
            } else {
                System.out.println("Vector product is defined only for 3D vectors.");
            }

        } catch (VectorException e) {
            System.err.println("Exception: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("General error: " + e.getMessage());
        } finally {
            input.close();
            System.out.println("\nProgram finished.");
        }
    }
}
