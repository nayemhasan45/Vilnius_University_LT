import java.util.Scanner;

public class AmicableNumbers {
    
    // Method to calculate sum of proper divisors
    public static int sumOfProperDivisors(int num) {
        int sum = 1; // 1 is always a proper divisor
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                sum += i;
                if (i != num / i) {
                    sum += num / i;
                }
            }
        }
        return sum;
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter n: ");
        int n = scanner.nextInt();
        
        System.out.println("Amicable pairs less than " + n + ":");
        
        for (int i = 2; i < n; i++) {
            int sum1 = sumOfProperDivisors(i);
            if (sum1 > i && sum1 < n) {
                int sum2 = sumOfProperDivisors(sum1);
                if (sum2 == i) {
                    System.out.println("(" + i + ", " + sum1 + ")");
                }
            }
        }
        
        scanner.close();
    }
}