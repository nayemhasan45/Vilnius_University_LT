// Abstract class Shape
public abstract class Shape {
    public abstract double getPerimeter();
    public abstract double getArea();
    public abstract void printNameShape();
    public abstract void print();
}
