import java.util.Scanner;

public class WordCountByLetters {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input string and letters
        System.out.print("Enter a sentence: ");
        String sentence = sc.nextLine();
        System.out.print("Enter the starting letter: ");
        char begin = sc.next().charAt(0);
        System.out.print("Enter the ending letter: ");
        char end = sc.next().charAt(0);
        sc.close();

        // Convert letters to lowercase for case-insensitive comparison
        begin = Character.toLowerCase(begin);
        end = Character.toLowerCase(end);

        int count = 0;
        // Split the string by whitespace to get words
        String[] words = sentence.split("\\s+");

        for (String word : words) {
            if (word.isEmpty()) continue;

            // Normalize to lowercase
            String w = word.toLowerCase();
            // Check first and last character
            if (w.charAt(0) == begin && w.charAt(w.length() - 1) == end) {
                count++;
            }
        }

        System.out.println("Number of words starting with '" + begin +
                           "' and ending with '" + end + "': " + count);
    }
}
