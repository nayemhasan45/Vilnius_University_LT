public class Test {
    public static void main(String[] args) {
        Triangle t = new Triangle(3, 4, 5);
        t.printNameShape();
        t.print();

        TriangularPrism tp = new TriangularPrism(3, 4, 5, 10);
        tp.printNameShape();
        tp.print();
    }
}
