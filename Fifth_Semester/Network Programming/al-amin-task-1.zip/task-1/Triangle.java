public class Triangle extends Shape {
    private double a, b, c;

    // No-args constructor (default sides = 1)
    public Triangle() {
        this(1, 1, 1);
    }

    // Constructor with arguments
    public Triangle(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    // Getters and setters
    public double getA() { return a; }
    public double getB() { return b; }
    public double getC() { return c; }

    public void setA(double a) { this.a = a; }
    public void setB(double b) { this.b = b; }
    public void setC(double c) { this.c = c; }

    @Override
    public double getPerimeter() {
        return a + b + c;
    }

    @Override
    public double getArea() {
        double s = getPerimeter() / 2.0;
        return Math.sqrt(s * (s - a) * (s - b) * (s - c)); // Heron's formula
    }

    @Override
    public void printNameShape() {
        System.out.println("Shape: Triangle");
    }

    @Override
    public void print() {
        System.out.printf(
            "Triangle with sides %.2f, %.2f, and %.2f, has a perimeter L=%.2f and an area P=%.2f.%n",
            a, b, c, getPerimeter(), getArea()
        );
    }
}
