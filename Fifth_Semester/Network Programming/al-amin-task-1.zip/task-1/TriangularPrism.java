public class TriangularPrism extends Triangle {
    private double height;

    // No-args constructor (default sides=1, height=1)
    public TriangularPrism() {
        super(1, 1, 1);
        this.height = 1;
    }

    // Constructor with arguments
    public TriangularPrism(double a, double b, double c, double height) {
        super(a, b, c);
        this.height = height;
    }

    // Getter & Setter
    public double getHeight() { return height; }
    public void setHeight(double height) { this.height = height; }

    // Surface area of prism = 2 * base area + base perimeter * height
    @Override
    public double getArea() {
        return 2 * super.getArea() + super.getPerimeter() * height;
    }

    // Volume = base area * height
    public double getVolume() {
        return super.getArea() * height;
    }

    @Override
    public void printNameShape() {
        System.out.println("Shape: Triangular Prism");
    }

    @Override
    public void print() {
        System.out.printf(
            "Triangular prism with a base with sides a=%.2f, b=%.2f and c=%.2f, and a height %.2f, "
          + "has an area P=%.2f and a volume V=%.2f.%n",
            getA(), getB(), getC(), height, getArea(), getVolume()
        );
    }
}
