import java.util.Random;

public class Test2 {
    public static void main(String[] args) {
        TriangularPrism[] prisms = new TriangularPrism[10];
        Random rand = new Random();

        // Create 10 prisms with random sides & heights
        for (int i = 0; i < prisms.length; i++) {
            double a = 2 + rand.nextDouble() * 8; // sides between 2 and 10
            double b = 2 + rand.nextDouble() * 8;
            double c = 2 + rand.nextDouble() * 8;
            double h = 1 + rand.nextDouble() * 10; // height between 1 and 11
            prisms[i] = new TriangularPrism(a, b, c, h);
        }

        // Find prism with smallest volume
        TriangularPrism smallest = prisms[0];
        for (int i = 1; i < prisms.length; i++) {
            if (prisms[i].getVolume() < smallest.getVolume()) {
                smallest = prisms[i];
            }
        }

        System.out.println("Triangular prism with smallest volume:");
        smallest.print();
    }
}
