import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.io.IOException;
import java.util.Map;
import java.util.Objects;

public class UdpCalcProtocol implements Runnable {

    // Simple container for one client "session"
    public static class ClientSession {
        public float x;
        public float y;

        public ClientSession(float x, float y) {
            this.x = x;
            this.y = y;
        }
    }

    // Key = (client IP, client port)
    public static class ClientKey {
        private final InetAddress address;
        private final int port;

        public ClientKey(InetAddress address, int port) {
            this.address = address;
            this.port = port;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof ClientKey)) return false;
            ClientKey other = (ClientKey) o;
            return port == other.port && address.equals(other.address);
        }

        @Override
        public int hashCode() {
            return Objects.hash(address, port);
        }
    }

    private final DatagramSocket socket;
    private final DatagramPacket packet;
    private final Map<ClientKey, ClientSession> sessions;

    public UdpCalcProtocol(DatagramSocket socket,
                           DatagramPacket packet,
                           Map<ClientKey, ClientSession> sessions) {
        this.socket = socket;
        // copy data so caller can reuse its buffer
        byte[] dataCopy = new byte[packet.getLength()];
        System.arraycopy(packet.getData(), packet.getOffset(), dataCopy, 0, packet.getLength());
        this.packet = new DatagramPacket(dataCopy, dataCopy.length,
                                         packet.getAddress(), packet.getPort());
        this.sessions = sessions;
    }

    @Override
    public void run() {
        try {
            handlePacket();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handlePacket() throws IOException {
        InetAddress clientAddr = packet.getAddress();
        int clientPort = packet.getPort();
        ClientKey key = new ClientKey(clientAddr, clientPort);

        String msg = new String(packet.getData(), 0, packet.getLength()).trim();
        System.out.println("Received from client: " + msg);

        String[] parts = msg.split("\\s+");

        // CASE 1: first message -> two floats X and Y
        if (parts.length == 2 && isFloat(parts[0]) && isFloat(parts[1])) {
            float x = Float.parseFloat(parts[0]);
            float y = Float.parseFloat(parts[1]);

            // store session state for this client
            sessions.put(key, new ClientSession(x, y));

            String menu = "Choose an operation:\n" +
                          "1. Addition (+)\n" +
                          "2. Subtraction (-)\n" +
                          "3. Multiplication (*)\n" +
                          "4. Division (/)";
            sendString(menu, clientAddr, clientPort);
            return;
        }

        // CASE 2: second message -> operation choice
        ClientSession session = sessions.get(key);
        if (session == null) {
            // server got choice, but no operands were stored
            String error = "Invalid input. Please send two float numbers.";
            sendString(error, clientAddr, clientPort);
            return;
        }

        float x = session.x;
        float y = session.y;
        float result = 0;
        boolean validChoice = true;

        switch (msg) {
            case "1":
            case "+":
                result = x + y;
                break;
            case "2":
            case "-":
                result = x - y;
                break;
            case "3":
            case "*":
                result = x * y;
                break;
            case "4":
            case "/":
                if (y == 0) {
                    sendString("Error: Division by zero!", clientAddr, clientPort);
                    sessions.remove(key);
                    return;
                }
                result = x / y;
                break;
            default:
                validChoice = false;
        }

        String response = validChoice ? ("Result: " + result) : "Wrong choice!";
        sendString(response, clientAddr, clientPort);

        // Session finished
        sessions.remove(key);
    }

    private boolean isFloat(String s) {
        try {
            Float.parseFloat(s);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private void sendString(String msg, InetAddress addr, int port) throws IOException {
        byte[] data = msg.getBytes();
        DatagramPacket out = new DatagramPacket(data, data.length, addr, port);
        socket.send(out);
    }
}
