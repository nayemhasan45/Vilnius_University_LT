import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class UDPServerThreadPerClient {

    private static final int PORT = 4444;
    private static final int BUFSIZE = 1024;

    // shared sessions map for all worker threads
    private static final Map<UdpCalcProtocol.ClientKey, UdpCalcProtocol.ClientSession> sessions =
            new ConcurrentHashMap<>();

    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket(PORT)) {
            System.out.println("UDP Thread-per-client Server running on port " + PORT);

            while (true) {
                DatagramPacket packet = new DatagramPacket(new byte[BUFSIZE], BUFSIZE);
                socket.receive(packet);  // ONLY here we receive

                // Spawn a new thread to process this one packet
                Thread t = new Thread(new UdpCalcProtocol(socket, packet, sessions));
                t.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
