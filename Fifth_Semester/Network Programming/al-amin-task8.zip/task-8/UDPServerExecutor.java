import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UDPServerExecutor {

    private static final int PORT = 4444;
    private static final int BUFSIZE = 1024;

    private static final Map<UdpCalcProtocol.ClientKey, UdpCalcProtocol.ClientSession> sessions =
            new ConcurrentHashMap<>();

    public static void main(String[] args) {
        ExecutorService executor = Executors.newCachedThreadPool(); 
        // You can also use:
        // Executors.newFixedThreadPool(4);

        try (DatagramSocket socket = new DatagramSocket(PORT)) {
            System.out.println("UDP Executor Server running on port " + PORT);

            while (true) {
                DatagramPacket packet = new DatagramPacket(new byte[BUFSIZE], BUFSIZE);
                socket.receive(packet); // ONLY HERE receive happens

                executor.execute(new UdpCalcProtocol(socket, packet, sessions));
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            executor.shutdown();
        }
    }
}
