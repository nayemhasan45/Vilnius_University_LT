import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

public class UDPServerPool {

    private static final int PORT = 4444;
    private static final int BUFSIZE = 1024;
    private static final int POOL_SIZE = 4; // you can change to 5, 10 etc.

    private static final Map<UdpCalcProtocol.ClientKey, UdpCalcProtocol.ClientSession> sessions =
            new ConcurrentHashMap<>();

    public static void main(String[] args) {
        BlockingQueue<DatagramPacket> queue = new LinkedBlockingQueue<>();

        try {
            DatagramSocket socket = new DatagramSocket(PORT);
            System.out.println("UDP Thread Pool Server running on port " + PORT + " with " + POOL_SIZE + " workers");

            // Start worker threads
            for (int i = 0; i < POOL_SIZE; i++) {
                Thread worker = new Thread(() -> {
                    while (true) {
                        try {
                            DatagramPacket packet = queue.take(); // wait for packet
                            new UdpCalcProtocol(socket, packet, sessions).run();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
                worker.start();
            }

            // Receiver loop (main thread)
            while (true) {
                DatagramPacket packet = new DatagramPacket(new byte[BUFSIZE], BUFSIZE);
                socket.receive(packet);
                queue.add(packet);  // give it to the worker pool
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
