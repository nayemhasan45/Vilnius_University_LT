import java.io.*;

public class TriangularPrismsToFile {
    public static void main(String[] args) {
        // Step 1: Create 6 TriangularPrism objects
        TriangularPrism[] prisms = {
            new TriangularPrism(3, 4, 5, 10),
            new TriangularPrism(5, 5, 8, 12),
            new TriangularPrism(6, 7, 8, 9),
            new TriangularPrism(4, 4, 6, 5),
            new TriangularPrism(8, 9, 10, 6),
            new TriangularPrism(2, 3, 4, 7)
        };

        // Step 2: Write them to a text file
        try {
            PrintWriter out = new PrintWriter(new FileWriter("TriangularPrisms6.txt"));
            for (TriangularPrism p : prisms) {
                out.println(p.print());
            }
            out.close();
            System.out.println("✅ TriangularPrisms6.txt file created successfully.\n");

        } catch (IOException e) {
            System.out.println("Error writing file: " + e.getMessage());
        }

        // Step 3: Read the same file and print on screen
        try {
            BufferedReader in = new BufferedReader(new FileReader("TriangularPrisms6.txt"));
            String line;
            System.out.println("Reading from TriangularPrisms6.txt:\n");
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
            in.close();
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}
