import java.io.*;
import java.net.URL;

public class ReadURLtoFile {
    public static void main(String[] args) {
        // Example URL - you can change to any text-based page
        String urlAddress = "https://www.example.com/";
        String fileName = "WebsiteData.txt";

        try {
            // Open connection to the URL
            URL url = new URL(urlAddress);
            BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
            PrintWriter writer = new PrintWriter(new FileWriter(fileName));

            String line;
            while ((line = reader.readLine()) != null) {
                writer.println(line);
            }

            reader.close();
            writer.close();

            System.out.println("✅ Web data saved to " + fileName);

        } catch (IOException e) {
            System.out.println("Error reading/writing data: " + e.getMessage());
        }
    }
}
