public class TriangularPrism {
    double a, b, c, height;

    public TriangularPrism(double a, double b, double c, double height) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.height = height;
    }

    public double getArea() {
        double s = (a + b + c) / 2;
        double baseArea = Math.sqrt(s * (s - a) * (s - b) * (s - c));
        double lateralArea = (a + b + c) * height;
        return 2 * baseArea + lateralArea;
    }

    public double getVolume() {
        double s = (a + b + c) / 2;
        double baseArea = Math.sqrt(s * (s - a) * (s - b) * (s - c));
        return baseArea * height;
    }

    public String print() {
        return "Triangular prism with a=" + a + ", b=" + b + ", c=" + c +
               ", height=" + height +
               ", area=" + String.format("%.2f", getArea()) +
               ", volume=" + String.format("%.2f", getVolume());
    }
}
