import java.net.*;
import java.io.*;

public class UDPServer {
    public static void main(String[] args) throws IOException {
        final int PORT = 4444;
        final int BUFSIZE = 1024;

        try (DatagramSocket socket = new DatagramSocket(PORT)) {
            System.out.println("UDP Server running on port " + PORT);

            while (true) {
                // Receive operands X and Y
                DatagramPacket receivePacket = new DatagramPacket(new byte[BUFSIZE], BUFSIZE);
                socket.receive(receivePacket);
                String receivedData = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Received from client: " + receivedData);

                String[] parts = receivedData.trim().split(" ");
                if (parts.length != 2) {
                    String errorMsg = "Invalid input. Please send two float numbers.";
                    DatagramPacket errorPacket = new DatagramPacket(
                            errorMsg.getBytes(),
                            errorMsg.length(),
                            receivePacket.getAddress(),
                            receivePacket.getPort()
                    );
                    socket.send(errorPacket);
                    continue;
                }

                float x, y;
                try {
                    x = Float.parseFloat(parts[0]);
                    y = Float.parseFloat(parts[1]);
                } catch (NumberFormatException e) {
                    String errorMsg = "Invalid number format!";
                    DatagramPacket errorPacket = new DatagramPacket(
                            errorMsg.getBytes(),
                            errorMsg.length(),
                            receivePacket.getAddress(),
                            receivePacket.getPort()
                    );
                    socket.send(errorPacket);
                    continue;
                }

                // Send operation menu
                String menu = "Choose an operation:\n1. Addition (+)\n2. Subtraction (-)\n3. Multiplication (*)\n4. Division (/)";
                DatagramPacket menuPacket = new DatagramPacket(
                        menu.getBytes(),
                        menu.length(),
                        receivePacket.getAddress(),
                        receivePacket.getPort()
                );
                socket.send(menuPacket);

                // Receive the user's choice
                DatagramPacket choicePacket = new DatagramPacket(new byte[BUFSIZE], BUFSIZE);
                socket.receive(choicePacket);
                String choice = new String(choicePacket.getData(), 0, choicePacket.getLength()).trim();

                float result;
                boolean validChoice = true;

                switch (choice) {
                    case "1":
                    case "+":
                        result = x + y;
                        break;
                    case "2":
                    case "-":
                        result = x - y;
                        break;
                    case "3":
                    case "*":
                        result = x * y;
                        break;
                    case "4":
                    case "/":
                        if (y == 0) {
                            String msg = "Error: Division by zero!";
                            DatagramPacket msgPacket = new DatagramPacket(
                                    msg.getBytes(), msg.length(),
                                    receivePacket.getAddress(), receivePacket.getPort()
                            );
                            socket.send(msgPacket);
                            continue;
                        }
                        result = x / y;
                        break;
                    default:
                        validChoice = false;
                        result = 0;
                }

                String response;
                if (validChoice) {
                    response = "Result: " + result;
                } else {
                    response = "Wrong choice!";
                }

                DatagramPacket responsePacket = new DatagramPacket(
                        response.getBytes(),
                        response.length(),
                        receivePacket.getAddress(),
                        receivePacket.getPort()
                );
                socket.send(responsePacket);
            }
        }
    }
}
