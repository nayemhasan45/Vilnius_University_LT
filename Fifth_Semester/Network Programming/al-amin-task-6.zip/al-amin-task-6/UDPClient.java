import java.net.*;
import java.io.*;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        final int PORT = 4444;

        System.out.print("Enter server IP (e.g., localhost): ");
        String serverHost = scanner.nextLine();
        InetAddress serverAddress = InetAddress.getByName(serverHost);

        try (DatagramSocket socket = new DatagramSocket()) {
            socket.setSoTimeout(10000);

            System.out.print("Enter first number (X): ");
            float x = scanner.nextFloat();
            System.out.print("Enter second number (Y): ");
            float y = scanner.nextFloat();
            scanner.nextLine(); // clear newline

            String message = x + " " + y;
            byte[] sendData = message.getBytes();

            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, PORT);
            socket.send(sendPacket);

            // Receive menu from server
            DatagramPacket menuPacket = new DatagramPacket(new byte[1024], 1024);
            socket.receive(menuPacket);
            String menu = new String(menuPacket.getData(), 0, menuPacket.getLength());
            System.out.println("\n" + menu);

            System.out.print("Enter your choice (1,2,3,4 or +,-,*,/): ");
            String choice = scanner.nextLine();
            DatagramPacket choicePacket = new DatagramPacket(choice.getBytes(), choice.length(), serverAddress, PORT);
            socket.send(choicePacket);

            // Receive result
            DatagramPacket resultPacket = new DatagramPacket(new byte[1024], 1024);
            socket.receive(resultPacket);
            String result = new String(resultPacket.getData(), 0, resultPacket.getLength());
            System.out.println("\nServer says: " + result);
        } catch (IOException e) {
            e.printStackTrace();
        }

        scanner.close();
    }
}
