public class SynchronizedAccount {
    private float balance;

    public SynchronizedAccount() { this.balance = 0; }
    public SynchronizedAccount(float balance) { this.balance = balance; }

    public synchronized float getBalance() { return balance; }

    public synchronized void deposit(float amount) { balance += amount; }

    public synchronized void withdrawal(float amount) {
        if (amount <= balance) { balance -= amount; }
    }
}
