import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorSynchronizedTest {
    public static void main(String[] args) {
        SynchronizedAccount account = new SynchronizedAccount(10000);
        ExecutorService executor = Executors.newFixedThreadPool(6);

        for (int i = 0; i < 6; i++) {
            executor.execute(new ChangeBalanceRunnableSync(account));
        }

        executor.shutdown();
    }
}
