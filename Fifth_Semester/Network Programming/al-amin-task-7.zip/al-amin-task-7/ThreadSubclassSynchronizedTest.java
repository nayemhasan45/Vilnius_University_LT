public class ThreadSubclassSynchronizedTest {
    public static void main(String[] args) {
        SynchronizedAccount account = new SynchronizedAccount(10000);

        for (int i = 0; i < 6; i++) {
            new ChangeBalanceThreadSync(account).start();
        }
    }
}
