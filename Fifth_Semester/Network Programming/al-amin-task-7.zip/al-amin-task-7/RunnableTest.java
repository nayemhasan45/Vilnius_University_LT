public class RunnableTest {
    public static void main(String[] args) {
        Account account = new Account(10000);

        for (int i = 0; i < 6; i++) {
            Thread t = new Thread(new ChangeBalanceRunnable(account));
            t.start();
        }
    }
}
