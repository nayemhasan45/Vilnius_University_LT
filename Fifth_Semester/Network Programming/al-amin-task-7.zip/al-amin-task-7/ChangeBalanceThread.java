import java.util.Random;

public class ChangeBalanceThread extends Thread {
    private Account account;
    private Random random = new Random();

    public ChangeBalanceThread(Account account) { this.account = account; }

    @Override
    public void run() {
        int choice = random.nextInt(15);
        float amount = random.nextFloat() * 3000;

        if (choice % 2 == 0) {
            account.deposit(amount);
            System.out.println("[Unsync] " + Thread.currentThread().getName() +
                    " deposited: " + amount + " | Balance: " + account.getBalance());
        } else {
            if (amount <= account.getBalance()) {
                account.withdrawal(amount);
                System.out.println("[Unsync] " + Thread.currentThread().getName() +
                        " withdrew: " + amount + " | Balance: " + account.getBalance());
            } else {
                System.out.println("[Unsync] " + Thread.currentThread().getName() +
                        " tried to withdraw " + amount + " but insufficient balance!");
            }
        }

        try { Thread.sleep(10); } catch (InterruptedException e) { e.printStackTrace(); }
    }
}
