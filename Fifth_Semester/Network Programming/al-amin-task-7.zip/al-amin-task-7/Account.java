public class Account {
    private float balance;

    public Account() { this.balance = 0; }
    public Account(float balance) { this.balance = balance; }

    public float getBalance() { return balance; }

    public void deposit(float amount) { balance += amount; }

    public void withdrawal(float amount) {
        if (amount <= balance) { balance -= amount; }
    }
}
