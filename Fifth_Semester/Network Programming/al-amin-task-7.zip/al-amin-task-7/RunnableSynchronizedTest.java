public class RunnableSynchronizedTest {
    public static void main(String[] args) {
        SynchronizedAccount account = new SynchronizedAccount(10000);

        for (int i = 0; i < 6; i++) {
            Thread t = new Thread(new ChangeBalanceRunnableSync(account));
            t.start();
        }
    }
}
